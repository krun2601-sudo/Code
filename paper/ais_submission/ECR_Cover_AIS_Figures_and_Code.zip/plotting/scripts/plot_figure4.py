"""Figure 4: repair ablation and planning-time budget."""

from __future__ import annotations

import numpy as np
import matplotlib.pyplot as plt

from io_utils import read_csv, read_json, save_all
from style import BLUE, GRAY, LIGHT_GRAY, MM, ORANGE, RED, TEAL, apply_style, clean_axis, panel_label


def ecdf(ax, values, label, color, linestyle="-"):
    x = np.sort(np.asarray(values, dtype=float))
    y = np.arange(1, len(x) + 1) / len(x)
    ax.step(x, y, where="post", label=label, color=color, ls=linestyle, lw=1.45)
    ax.plot(x, np.full_like(x, -0.035), "|", color=color, ms=4, clip_on=False)


def main():
    apply_style()
    pairs = read_csv("paired_repair_effects.csv")
    audit = read_json("V243_COMPLETE_AUDIT.json")
    assert len(pairs) == 10, "Expected 10 repair pairs."

    fig, axes = plt.subplots(1, 3, figsize=(178 * MM, 64 * MM), gridspec_kw={"width_ratios": [1.0, 0.92, 1.15]})
    ax, bx, cx = axes

    # Preserve block identity while adding tiny deterministic offsets for visibility.
    for row in pairs:
        off = float(row["uac_off_s"])
        on = float(row["uac_on_s"])
        color = TEAL if on < off else ORANGE
        ax.plot([0, 1], [off, on], color=color, lw=1.1, alpha=0.8)
        ax.scatter([0, 1], [off, on], color=[GRAY, color], s=22, zorder=3, edgecolor="white", lw=0.4)
    ax.set_xticks([0, 1], ["Repair off", "Repair on"])
    ax.set_ylabel("UAC (s)")
    clean_axis(ax, "y")
    ax.set_title("Paired repair ablation", weight="bold", pad=7)
    panel_label(ax, "a")

    ratios = np.asarray([float(row["t100_on_over_off"]) for row in pairs])
    y = np.arange(1, len(ratios) + 1)
    bx.axvline(1.0, color=GRAY, ls="--", lw=0.9, label="Equality")
    bx.axvline(1.05, color=RED, ls=":", lw=1.2, label="5% margin")
    bx.scatter(ratios, y, s=24, color=BLUE, edgecolor="white", lw=0.4, zorder=3)
    med = 0.9980111963
    lo, hi = 0.9541716411, 1.0000639547
    bx.plot([lo, hi], [0, 0], color=TEAL, lw=2.0)
    bx.plot([lo, lo], [-0.18, 0.18], color=TEAL, lw=1.0)
    bx.plot([hi, hi], [-0.18, 0.18], color=TEAL, lw=1.0)
    bx.scatter([med], [0], marker="D", s=34, color=TEAL, edgecolor="white", lw=0.4, zorder=4)
    bx.text(0.952, -0.70, "Median [95% CI]", fontsize=6.7, color=TEAL, ha="left")
    bx.set_xlabel("T100 ratio: repair on/off")
    bx.set_yticks([0, 1, 5, 10], ["Summary", "1", "5", "10"])
    bx.set_ylabel("Pair")
    bx.set_ylim(-1.1, 10.7)
    bx.set_xlim(0.90, 1.065)
    clean_axis(bx, "x")
    bx.set_title("T100 noninferiority", weight="bold", pad=7)
    panel_label(bx, "b", -0.16)

    initial = [float(r["initial_planner_ms"]) / 200.0 for r in audit["runs"]]
    repair = [float(v) / 40.0 for r in audit["runs"] for v in r["repair_planner_ms"]]
    ecdf(cx, initial, "Initial plan (200 ms)", BLUE, "-")
    ecdf(cx, repair, "Event repair (40 ms)", ORANGE, "--")
    cx.axvline(1.0, color=RED, ls=":", lw=1.2, label="Budget")
    cx.set_xlabel("Planning time / budget")
    cx.set_ylabel("Empirical cumulative probability")
    cx.set_ylim(0, 1.04)
    cx.set_xlim(0, 1.03)
    clean_axis(cx, "both")
    cx.legend(frameon=False, loc="lower right", handlelength=2.5)
    cx.set_title("Observed planning-time budget", weight="bold", pad=7)
    panel_label(cx, "c")

    fig.subplots_adjust(left=0.075, right=0.995, bottom=0.20, top=0.83, wspace=0.42)
    save_all(fig, "figure4_repair")
    plt.close(fig)


if __name__ == "__main__":
    main()

