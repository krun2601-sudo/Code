"""Figure 3: nominal hardware experiments."""

from __future__ import annotations

import numpy as np
import matplotlib.pyplot as plt

from io_utils import read_csv, save_all
from style import BLUE, GRAY, MM, ORANGE, TEAL, apply_style, clean_axis, panel_label


METHODS = [
    ("mag", "MAG", GRAY, "o", "-"),
    ("measured_static", "Calibrated static", ORANGE, "s", "--"),
    ("uac_robust_repair_v2", "ECR-Cover", TEAL, "^", "-"),
]


def ecdf(ax, values, label, color, marker, linestyle):
    values = np.sort(np.asarray(values, dtype=float))
    y = np.arange(1, len(values) + 1) / len(values)
    ax.step(values, y, where="post", color=color, linestyle=linestyle, label=label, lw=1.45)
    ax.plot(values, np.full_like(values, -0.035), marker=marker, ms=3.6, ls="none", color=color, clip_on=False)


def main():
    apply_style()
    rows = [r for r in read_csv("formal_run_metrics_wide.csv") if r["condition"] == "nominal"]
    by_method = {key: [r for r in rows if r["method"] == key] for key, *_ in METHODS}
    assert all(len(v) == 10 for v in by_method.values()), "Expected 10 nominal runs per method."

    fig, axes = plt.subplots(1, 3, figsize=(178 * MM, 61 * MM), gridspec_kw={"width_ratios": [1.08, 0.86, 1.08]})
    ax, bx, cx = axes

    for key, label, color, marker, linestyle in METHODS:
        ecdf(ax, [float(r["uac_h_s"]) for r in by_method[key]], label, color, marker, linestyle)
    ax.set_xlabel("UAC (s)")
    ax.set_ylabel("Empirical cumulative probability")
    ax.set_ylim(0, 1.04)
    clean_axis(ax, "both")
    ax.legend(frameon=False, loc="lower right", handlelength=2.6)
    ax.set_title("Run-level first-coverage latency", weight="bold", pad=7)
    panel_label(ax, "a")

    labels = ["vs MAG", "vs calibrated\nstatic"]
    med = np.array([-4.9413626957, -0.2654152243])
    lo = np.array([-6.7071104255, -1.0463878434])
    hi = np.array([-3.9104763393, -0.1104119954])
    yy = np.array([1, 0])
    bx.axvline(0, color=GRAY, lw=0.9, ls="--")
    for y, m, l, h in zip(yy, med, lo, hi):
        bx.plot([l, h], [y, y], color=BLUE, lw=1.8)
        bx.plot([l, l], [y - 0.08, y + 0.08], color=BLUE, lw=1.0)
        bx.plot([h, h], [y - 0.08, y + 0.08], color=BLUE, lw=1.0)
        bx.scatter([m], [y], s=32, marker="D", color=TEAL, edgecolor="white", lw=0.5, zorder=3)
    bx.set_yticks(yy, labels)
    bx.set_xlabel("Paired UAC difference (s)")
    bx.set_ylim(-0.55, 1.55)
    clean_axis(bx, "x")
    bx.set_title("Median difference [95% CI]", weight="bold", pad=7)
    panel_label(bx, "b", -0.18)

    for key, label, color, marker, linestyle in METHODS:
        ecdf(cx, [float(r["t100_s"]) for r in by_method[key]], label, color, marker, linestyle)
    cx.set_xlabel("T100 (s)")
    cx.set_ylim(0, 1.04)
    cx.set_yticklabels([])
    clean_axis(cx, "both")
    cx.set_title("Run-level completion tail", weight="bold", pad=7)
    panel_label(cx, "c")

    fig.subplots_adjust(left=0.075, right=0.995, bottom=0.20, top=0.83, wspace=0.38)
    save_all(fig, "figure3_nominal")
    plt.close(fig)


if __name__ == "__main__":
    main()

